
import streamlit as st

st.title("AuditAI PreCheck")
st.write("Fichier d'application chargé avec succès. Remplacez ce code par la version complète.")
